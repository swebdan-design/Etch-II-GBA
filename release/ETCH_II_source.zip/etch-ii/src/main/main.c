/*
 * ETCH II -- A Generative Synthesis Machine -- by Synth Centric
 * Boot, interrupt dispatch, main loop and global controls.
 *
 * Division of labour:
 *   VBlank IRQ (ARM, IWRAM): DMA restart, sequencer, synthesis, mixing.
 *   Main loop (Thumb, ROM):  input, screens, CORROSION candidate
 *                            preparation, REGEN material, saving/loading.
 * The interrupt never waits for the main loop; the main loop hands musical
 * data over in short critical sections (as ETCH's timer ISR / main loop).
 */
#include "gba.h"
#include "audio.h"
#include "seq.h"
#include "ui.h"
#include "evolve.h"
#include "storage.h"
#include "album.h"

project2_t proj EWRAM_BSS;
uint8_t app_screen = SCR_LIVE, app_track;
uint8_t app_need_redraw = 1;
volatile uint32_t frame_count;
volatile uint16_t main_worst;              /* longest main-loop pass, frames */
char *fake_heap_end, *fake_heap_start;     /* referenced by devkitPro's crt0 */
static uint8_t last_commits;
/* test hooks (tests/emu_test.py): each runs the same app path a user action does */
volatile uint8_t probe_album;              /* 1..8: load that album piece          */
volatile uint8_t probe_tempo;              /* 1: apply bpm/swing/gate              */
volatile uint8_t probe_paste;              /* n+1: paste probe_pat into pattern n  */
volatile uint8_t probe_save, probe_load;   /* n+1: save / load slot n              */
volatile uint8_t probe_result;
pattern_t probe_pat EWRAM_BSS;

void irq_entry(void);
void irq_dispatch(uint32_t flags) IWRAM_CODE;

/* called from irq.s in SYS mode with IRQs masked */
void irq_dispatch(uint32_t flags)
{
    if (flags & IRQ_VBLANK) {
        audio_vblank();
        frame_count++;
        ui_key_sample();                      /* no press is lost while the UI draws */
    }
}

void app_redraw(void) { app_need_redraw = 1; }
void app_go(uint8_t s) { app_screen = (uint8_t)(s % SCR_COUNT); app_need_redraw = 1; }

static void enter_screen(void)
{
    switch (app_screen) {
    case SCR_LIVE:   scr_live_enter(); break;
    case SCR_TRACK:  scr_track_enter(); break;
    case SCR_SYNTH:  scr_synth_enter(); break;
    case SCR_MOD:    scr_mod_enter(); break;
    case SCR_GEN:    scr_gen_enter(); break;
    case SCR_MEMORY: scr_memory_enter(); break;
    case SCR_SONG:   scr_song_enter(); break;
    default:         scr_file_enter(); break;
    }
}

static void frame_screen(void)
{
    switch (app_screen) {
    case SCR_LIVE:   scr_live_frame(); break;
    case SCR_TRACK:  scr_track_frame(); break;
    case SCR_SYNTH:  scr_synth_frame(); break;
    case SCR_MOD:    scr_mod_frame(); break;
    case SCR_GEN:    scr_gen_frame(); break;
    case SCR_MEMORY: scr_memory_frame(); break;
    case SCR_SONG:   scr_song_frame(); break;
    default:         scr_file_frame(); break;
    }
}

void app_set_compat(uint8_t c)
{
    proj.compat = c ? COMPAT_EXPANDED : COMPAT_CLASSIC;
    if (proj.compat == COMPAT_CLASSIC) {
        uint8_t v;
        CRITICAL { for (v = V_LEAD; v < N_MELODIC; v++) voice_gate_off(v); }
    }
}

void app_load_album(uint8_t i)
{
    uint8_t was = seq_playing;
    seq_stop();
    CRITICAL { audio_all_off(); }
    album_load(i, &proj);
    app_project_loaded();
    if (was) { seq_seed_live(ui_entropy); seq_start(); }
    app_redraw();
}

void app_new_project(void)
{
    seq_stop();
    CRITICAL { audio_all_off(); }
    project_defaults(&proj);
    proj.gen.seed = (uint16_t)evo_random();
    app_project_loaded();
    app_redraw();
}

/* ---- global keys -------------------------------------------------------------- */
static uint8_t r_fill;                       /* the fill R is holding */

static void global_keys(void)
{
    /* hold R: fill while held (SERIES_SPEC.md 2.1).  It lets go of only the
     * fill it started; a fill latched with SELECT+START or B stays on. */
    if ((key_released & KEY_R) && r_fill) {
        r_fill = 0;
        if (seq_fill_hold) { app_fill_toggle(); ui_msg("FILL OFF"); }
    }
    if (key_held & KEY_SELECT) {
        if (key_pressed & KEY_RIGHT) app_go((uint8_t)(app_screen + 1));
        if (key_pressed & KEY_LEFT) app_go((uint8_t)(app_screen + SCR_COUNT - 1));
        if (key_pressed & (KEY_UP | KEY_DOWN)) {
            uint8_t base = seq_queued != 0xFF ? seq_queued : seq_cur;
            int8_t d = (key_pressed & KEY_UP) ? 1 : -1;
            seq_queue_pattern((uint8_t)((base + E2_PATTERNS + d) % E2_PATTERNS));
            if (proj.song.song) { proj.song.song = 0; ui_msg("LOOP MODE: PATTERN QUEUED"); }
            if (!seq_playing) app_redraw();
        }
        if (key_pressed & KEY_A) {
            if (proj.pat[seq_cur].lock & PLOCK_ALL) ui_msg("PATTERN LOCKED");
            else { app_evolve_now(); ui_msg(seq_playing ? "EVOLVE AT NEXT BAR" : "EVOLVED"); app_redraw(); }
        }
        if (key_pressed & KEY_B) { ui_msg(app_undo() ? "UNDO: PREVIOUS GENERATION" : "NOTHING TO UNDO"); app_redraw(); }
        if (key_pressed & KEY_START) { app_fill_toggle(); ui_msg(seq_fill_hold ? "FILL ON (SELECT+START: OFF)" : "FILL OFF"); }
        if (key_pressed & KEY_R) { app_track = (uint8_t)((app_track + 1) % TRK_COUNT); app_redraw(); }
        if (key_pressed & KEY_L) { app_track = (uint8_t)((app_track + TRK_COUNT - 1) % TRK_COUNT); app_redraw(); }
        ui_consume();
    } else if (key_held & KEY_B) {
        if (key_pressed & KEY_R) { app_track = (uint8_t)((app_track + 1) % TRK_COUNT); app_redraw(); }
        if (key_pressed & KEY_L) { app_track = (uint8_t)((app_track + TRK_COUNT - 1) % TRK_COUNT); app_redraw(); }
        if (key_pressed & (KEY_L | KEY_R)) ui_consume();
    } else {
        if ((key_pressed & KEY_R) && !seq_fill_hold) { app_fill_toggle(); r_fill = 1; ui_msg("FILL (RELEASE R: OFF)"); }
        if (key_pressed & KEY_START) {
            if (seq_playing) seq_stop();
            else { seq_seed_live(ui_entropy); seq_start(); }
        }
    }
}

/* Boot progress on screen: if start-up ever stops on real hardware, the
 * last line shown names the stage (and its colour), instead of a white
 * screen (the GBA shows white while the display is blanked). */
static void boot_stage(uint8_t n, const char *what)
{
    static const uint16_t col[8] = { 0x7BDE, 0x77BD, 0x739C, 0x6F7B, 0x6B5A, 0x6739, 0x6318, 0x5EF7 };   /* light greys */
    PAL_BG[0] = col[n & 7];
    ui_text(0, 18, "STARTING", PAL_DIM);
    ui_put(9, 18, (uint8_t)('0' + n), PAL_VALUE);
    ui_textn(11, 18, what, 19, PAL_DIM);
}

int main(void)
{
    REG_IME = 0;
    REG_DISPCNT = DCNT_BLANK;
    REG_WAITCNT = 0x4003;                    /* SRAM 8, ROM 4/2 (safe on flash carts), prefetch */
    REG_SOUNDBIAS = 0x0200;                  /* BIOS default; carts that skip the BIOS may not set it */
    ui_init();
    REG_DISPCNT = DCNT_MODE0 | DCNT_BG0;     /* display on before anything slow */
    boot_stage(1, "MEMORY");
    evo_init();
    project_defaults(&proj);
    boot_stage(2, "ALBUM");
    album_load(0, &proj);
    boot_stage(3, "VOICES");
    voice_init_all();
    drums_init();
    boot_stage(4, "MIXER");
    mixer_init();
    seq_init();
    boot_stage(5, "PERCUSSION");
    app_project_loaded();                    /* renders the drum kits */
    boot_stage(6, "INTERRUPTS");
    BIOS_IRQ_VECTOR = (uint32_t)irq_entry;
    REG_DISPSTAT = DSTAT_VBL_IRQ;
    REG_IE = IRQ_VBLANK;
    REG_IF = 0xFFFF;
    REG_IME = 1;
    vblank_wait_bios();                      /* proves the interrupt works */
    boot_stage(7, "SAVE MEMORY");
    storage_init();
    PAL_BG[0] = 0x7FFF;                      /* the backdrop is the canvas's BG (white) */

    scr_title_run();                          /* returns when START is pressed */

    seq_seed_live(ui_entropy);                /* the moment START was pressed */
    app_screen = SCR_LIVE;
    app_need_redraw = 1;
    seq_start();                              /* press START, hear music */
    last_commits = evo_commits;

    for (;;) {
        uint32_t f0;
        vblank_wait_bios();
        f0 = frame_count;
        if (probe_album) { app_load_album((uint8_t)(probe_album - 1)); probe_album = 0; }
        if (probe_tempo) { seq_set_tempo(); probe_tempo = 0; }
        if (probe_paste) {
            uint8_t n = (uint8_t)(probe_paste - 1);
            seq_backup_for_undo(n);
            CRITICAL { proj.pat[n] = probe_pat; }
            app_pattern_edited(n);
            probe_paste = 0;
        }
        if (probe_save) { probe_result = storage_save((uint8_t)(probe_save - 1)); probe_save = 0; }
        if (probe_load) {
            uint8_t was = seq_playing;
            seq_stop();
            CRITICAL { audio_all_off(); }
            probe_result = storage_load((uint8_t)(probe_load - 1));
            if (probe_result) app_project_loaded();
            if (was) seq_start();
            probe_load = 0;
        }
        ui_input();
        global_keys();
        if (app_need_redraw) {
            app_need_redraw = 0;
            ui_cls();
            enter_screen();
        } else {
            frame_screen();
        }
        ui_header_update();
        ui_msg_tick();
        app_fill_service();
        if (evo_commits != last_commits) {
            last_commits = evo_commits;
            evo_after_commit();
            if (app_screen == SCR_LIVE || app_screen == SCR_MEMORY || app_screen == SCR_TRACK) {
                static char m[] = "EVOLVED  GEN 000";
                uint8_t g = proj.pat[seq_cur].gen;
                m[13] = (char)('0' + g / 100); m[14] = (char)('0' + (g / 10) % 10); m[15] = (char)('0' + g % 10);
                ui_msg(m);
            }
        }
        evo_stable_reset();
        if (!evo_service()) regen_service();     /* one heavy job per pass at most */
        drum_cache_service();                    /* keep the percussion renders fresh */
        f0 = frame_count - f0;
        if (f0 > main_worst) main_worst = (uint16_t)f0;
    }
}
